<?php

add_filter('cartflows_remove_theme_styles', '__return_false', 10, 1);
add_filter('cartflows_remove_theme_scripts', '__return_false', 10, 1);

